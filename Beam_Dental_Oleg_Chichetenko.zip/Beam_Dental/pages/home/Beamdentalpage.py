from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains





class Beamdentalpg():
    def __init__(self, driver):
        self.driver = driver

    def verify_pagetitle(self):
        get_title = self.driver.title
        assert "Member Details" == get_title
        print("title  " + get_title + "  found")


    def verifyheader(self):
        member_details_header = self.driver.find_element(By.XPATH, "//h3[contains(text(),'Member Details')]").get_attribute("innerHTML")
        print(member_details_header + "  is found")
        assert "Member Details" == member_details_header

    def verifylogo(self):
        getlogo = self.driver.find_element(By.XPATH, "//img[@src='/beam_logo.svg']")
        if getlogo is not None:
            print("Logo is found")

    def get_customername(self, custname):
        customername = self.driver.find_element(By.XPATH, "//div//input[@class='MuiInputBase-input MuiInput-input Mui-disabled Mui-disabled']").get_attribute("value")
        assert custname == customername
        print("Customer  "+custname + "   is present on page")

    def verify_shippingheader(self):
        shipping_header = self.driver.find_element(By.XPATH, "//h5[contains(text(),'Shipping Address')]").text
        assert shipping_header == "Shipping Address"

    def verifyaddress_inputfalse(self):
        street = self.driver.find_element(By.XPATH, "//div[@class='MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12']").text
        assert street == "Address *"
        streetinputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/input[1]").is_enabled()
        a = False
        assert a == streetinputfield
        streetinputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/input[1]").get_attribute("value")


        city = self.driver.find_element(By.XPATH, "(//label[@class='MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink MuiInputLabel-outlined Mui-disabled Mui-disabled MuiFormLabel-filled Mui-required Mui-required'])[2]").text
        assert city == "City *"
        cityinputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[1]/div[1]/input[1]").is_enabled()
        a = False
        assert a == cityinputfield
        cityinputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[1]/div[1]/input[1]").get_attribute("value")

        state = self.driver.find_element(By.XPATH, "(//label[@class='MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink MuiInputLabel-outlined Mui-disabled Mui-disabled MuiFormLabel-filled Mui-required Mui-required'])[3]").text
        assert state == "State *"
        stateimputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[3]/div[1]/div[1]/input[1]").is_enabled()
        a = False
        assert a == stateimputfield
        stateimputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[3]/div[1]/div[1]/input[1]").get_attribute("value")

        zipcode = self.driver.find_element(By.XPATH,"(//label[@class='MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink MuiInputLabel-outlined Mui-disabled Mui-disabled MuiFormLabel-filled Mui-required Mui-required'])[4]").text
        assert zipcode == "Zip Code *"
        zipcodeimputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[4]/div[1]/div[1]/input[1]").is_enabled()
        a = False
        assert a == zipcodeimputfield
        zipcodeimputfield = self.driver.find_element(By.XPATH, "//body/div[@id='root']/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[4]/div[1]/div[1]/input[1]").get_attribute("value")

        print("Saved shipping address  "  + streetinputfield + "   " + cityinputfield + "   " + stateimputfield + "   " + zipcodeimputfield)

    def editbutton(self):
        time.sleep(1)
        editbutton = self.driver.find_element(By.XPATH,"//span[contains(text(),'Edit')]").click()


    def verifyaddress_inputtrue(self):
        street1_inputfield = self.driver.find_element(By.XPATH, "(//input[@class='MuiInputBase-input MuiOutlinedInput-input'])[1]").get_attribute("value")
        city1_inputfield = self.driver.find_element(By.XPATH,"(//input[@class='MuiInputBase-input MuiOutlinedInput-input'])[2]").get_attribute("value")
        state1_inputfield = self.driver.find_element(By.XPATH,"(//input[@class='MuiInputBase-input MuiOutlinedInput-input'])[3]").get_attribute("value")
        zipcode1_inputfield = self.driver.find_element(By.XPATH,"(//input[@class='MuiInputBase-input MuiOutlinedInput-input'])[4]").get_attribute("value")
        print("address is  " + street1_inputfield +"  "+ city1_inputfield +"  "+ state1_inputfield +"  " + zipcode1_inputfield)

    def updatebutton(self):
        updatebutton = self.driver.find_element(By.XPATH,"//span[@class='MuiButton-label']").click()

    def updatesavedpopup(self):
        time.sleep(1)
        updatesavedpopup = self.driver.find_element(By.ID, "client-snackbar")
        if updatesavedpopup is not None:
            print("address is saved")

    def clearzip(self):
        time.sleep(1)

        zipcode1_inputfield = self.driver.find_element(By.XPATH,"(//input[@class='MuiInputBase-input MuiOutlinedInput-input'])[4]").send_keys(Keys.SHIFT,Keys.HOME, Keys.DELETE)
        time.sleep(1)
        zipcodereq = self.driver.find_element(By.XPATH, "//p[contains(text(),'Zip Code is Required.')]")

    def updatebutton_dis(self):
        udpatebuttdis = self.driver.find_element(By.ID,"edit-button").is_enabled()
        a = False
        assert a == udpatebuttdis

    def brushcolor(self):
        preferences = self.driver.find_element(By.XPATH, "//span[contains(text(),'Preferences')]").click()
        time.sleep(3)
        Brushcolor_label = self.driver.find_element(By.XPATH, "//p[contains(text(),'Brush Color')]").text
        a = "Brush Color"
        assert a == Brushcolor_label

        Brushcolor = self.driver.find_element(By.XPATH,"(//*[@fill])[2]").get_attribute("fill")
        if Brushcolor ==  "#f31884":
            print("Customer uses beam-brush-pink ")
        if Brushcolor == "00c9f0":
            print("Customer uses beam-brush-blu")
        if Brushcolor == "daff00":
            print("Customer uses beam-brush-chartreuse")

    def moto_auto_labels(self):
        motor_speed_label = self.driver.find_element(By.XPATH,"//p[contains(text(),'Motor Speed')]")
        autooff_label = self.driver.find_element(By.XPATH, "//p[contains(text(),'Auto Off')]")
        autooffvalue = self.driver.find_element(By.XPATH, "//td[contains(text(),'Yes')]")
        if motor_speed_label and autooff_label and autooffvalue is not None:
            print("requited elements present on the page")






































