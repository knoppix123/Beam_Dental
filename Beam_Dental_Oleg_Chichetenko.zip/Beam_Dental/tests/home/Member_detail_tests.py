from selenium import webdriver
import pytest
import unittest
from pages.home.Beamdentalpage import Beamdentalpg



class MemberDetailPage(unittest.TestCase):

    def setUp(self):
        baseURL = "http://localhost:3000/"

        driver = webdriver.Chrome()   # use Chrome browser for testing
        driver.maximize_window()      # Open browser on Fullscreen
        driver.implicitly_wait(3)     # don't run test 3 seconds
        driver.get(baseURL)
        self.bd = Beamdentalpg(driver)
        self.driver = driver



    @pytest.mark.run(order=1)
    def testverify_page(self):
        self.bd.verify_pagetitle()  # verify title of the page
        self.bd.verifyheader()      # verify that page has "Member details"
        self.bd.verifylogo()        # verify company logo
        self.bd.get_customername("Remy LeBeau")  # Verify Customer name is displayed correctly
        self.bd.verify_shippingheader() #Verify shipping address section is present
        self.bd.verifyaddress_inputfalse()  # verify shipping section has input address forms and labels of these forms

    @pytest.mark.run(order=2)
    def testmember_shipping(self):
        self.bd.editbutton()                   # verify Edit button is present and able to click on it
        self.bd.verifyaddress_inputtrue()      # verify forms of shippping section is active after edit button was clicked
        self.bd.updatebutton()                 #verify "update" button works
        self.bd.updatesavedpopup()             #verify  shipping address was saved, confirmation displayed
        self.bd.verifyaddress_inputfalse()     # verify updated address is displayed , forms is not active

    @pytest.mark.run(order=3)
    def test_ship_form(self):
        self.bd.editbutton()        # edit button is clicked
        self.bd.clearzip()          # make zip form is empty
        self.bd.updatebutton_dis()  # update buttons is disabled if input form is empty

    @pytest.mark.run(order=4)
    def test_brush_preferences(self):
        self.bd.brushcolor()        #verify brush color
        self.bd.moto_auto_labels()  # verify he member's `motor_speed` and `auto_off` options are displayed on the page.





















